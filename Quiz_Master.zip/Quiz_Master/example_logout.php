<?php
	include_once( './uservalidation.php' );
	process_logout();
?>
