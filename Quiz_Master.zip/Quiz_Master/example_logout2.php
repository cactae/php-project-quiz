<?php
	include_once( './studentvalidation.php' );
	process_logout();
?>
