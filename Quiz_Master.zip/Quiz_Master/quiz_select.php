<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>QuizMaster</title>
	<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<table width="900" border="0" align="center">
<tr>
	<td width="180"><h2>
<br/>
	        Quiz Master</h2></td>
	<td width="750" colspan="2">
	<div class="section_1">
<br>
	        <p>Logout</p>
		</div>	</td>
</tr>
<tr>


<br><br>
</div>
</td>

<!-- the cell in which form is, starts here -->

<td width="750" colspan="2" >
<div class="osa_4">
<p>Hei, <b> <?php echo $nimi ?></b></p>
<p></p>
<table>
  <tr><td><strong><a href="quiz_1.php">Quiz 1<br></a></td></tr>
  <tr></tr>
  <tr><td><strong><a href="#">Quiz 2</a></strong></td></tr>
  <tr></tr>
  <tr><td><strong><a href="#">Quiz 3</a></strong></td></tr>
  <tr></tr>
  <tr><td><strong><a href="#">Quiz 4</a></strong></td></tr>
  <tr></tr>
  <tr><td><strong><a href="#">Quiz 5</a></strong></td></tr>
</table>

</div>
</td>

<!-- the cell in which form is, ends here -->

</tr>
</table>
</body>
</html>
